//
//  ViewController.swift
//  Meme2
//
//  Created by Joyous Joy on 7/19/17.
//  Copyright © 2017 Humphrey Corporations. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    
    @IBOutlet weak var imagePickerView: UIImageView!
    
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    
    
    @IBOutlet weak var memeActionsToolbar: UIToolbar!
    
    
    @IBOutlet weak var photoActionsToolbar: UIToolbar!
    
    var newMeme: Meme!
    
    
    var originalFramePositionY : CGFloat!
    
    struct Meme
    {
        var topText: String!
        var bottomText: String!
        var originalImage: UIImage!
        var memeImage: UIImage!
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        let memeTextAttributes : [String: Any] =
        [
            NSStrokeColorAttributeName: UIColor.white,
            NSForegroundColorAttributeName: UIColor.cyan,
            NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSStrokeWidthAttributeName: Float(5)
        ]
 
        topTextField.defaultTextAttributes = memeTextAttributes
        bottomTextField.defaultTextAttributes = memeTextAttributes
        
        topTextField.textAlignment = NSTextAlignment.center
        bottomTextField.textAlignment = NSTextAlignment.center
        
        originalFramePositionY = view.frame.origin.y
        
        subscribeToKeyboardNotifications()
    }
    
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        
        unsubscribeFromKeyboardNotifications()
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
    }
    
    
    func keyboardWillShow(_ notification:Notification) {
        
        view.frame.origin.y -= getKeyboardHeight(notification)
    }
    
    func keyboardWillHide(_ notification:Notification) {
        
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }

    
    
    
    
    
    
    
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var albumButton: UIBarButtonItem!
    
    let imagePicker = UIImagePickerController()
    
    @IBAction func shareButonPressed()
    {
        
        
        let activityController = UIActivityViewController.init(activityItems: [generateMemedImage()], applicationActivities: nil)
        
        self.present(activityController, animated: true, completion: nil)
        
        save()
        
    }
    
    
    func generateMemedImage() -> UIImage
    {
        memeActionsToolbar.isHidden = true
        photoActionsToolbar.isHidden = true
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        
        let memedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        
        UIGraphicsEndImageContext()
        
        memeActionsToolbar.isHidden = false
        photoActionsToolbar.isHidden = false
        
        return memedImage
    }
    
    func saveOld()
    {
        // Create the meme
        newMeme = Meme(topText: topTextField.text, bottomText: bottomTextField.text, originalImage: imagePickerView.image, memeImage: generateMemedImage())
    }
    
    func save()
    {
        // Create the meme
        newMeme =  Meme(topText: topTextField.text, bottomText: bottomTextField.text, originalImage: imagePickerView.image, memeImage: generateMemedImage())
    }
    
    @IBAction func cancelButonPressed()
    {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    @IBAction func cameraButonPressed()
    {
        if UIImagePickerController.isSourceTypeAvailable(.camera)
        {
            imagePicker.sourceType = .camera
            imagePicker.delegate = self
        
            self.present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            print("Camera not available")
        }
    }
    
    @IBAction func albumButonPressed()
    {
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        imagePickerView.image = image
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker.dismiss(animated: true, completion: nil)
    }
    
}

